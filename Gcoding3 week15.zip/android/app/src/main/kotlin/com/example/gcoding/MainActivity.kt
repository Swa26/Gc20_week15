package com.example.gcoding

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
