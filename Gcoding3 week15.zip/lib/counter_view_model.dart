import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter/material.dart';

final stateProvider =
    ChangeNotifierProvider<Counterviewmodel>((ref) => Counterviewmodel());

class Counterviewmodel extends ChangeNotifier {
  int _counter = 0;
  int get counter => _counter;
  void add() {
    _counter++;
    notifyListeners();
  }
}
