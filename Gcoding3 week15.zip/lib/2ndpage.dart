import 'package:flutter/material.dart';
import 'package:gcoding/counter_view.dart';
import 'package:gcoding/counter_view_model.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

class Counterview2 extends HookConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final provider = ref.watch(stateProvider);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: SafeArea(
        child: Scaffold(
          appBar: AppBar(
            title: const Text('CounterApp Page 2'),
          ),
          body: Center(
            child: Container(
              child: Column(
                children: [
                  Text(
                    provider.counter.toString(),
                    style: TextStyle(fontSize: 50.0),
                  ),
                  MaterialButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => Counterview(),
                        ),
                      );
                    },
                    child: Text("Click Here to redirect first page"),
                  )
                ],
              ),
            ),
          ),
          floatingActionButton: FloatingActionButton(
            child: Icon(Icons.add),
            onPressed: () {
              provider.add();
            },
          ),
        ),
      ),
    );
  }
}
